<?php
    
    define('HOST','localhost');
    define('USER','id2372099_perfectwebservice');
    define('PASS','prakruti123');
    define('DB','id2372099_perfectwebservice');
    
    $con=mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');
?>